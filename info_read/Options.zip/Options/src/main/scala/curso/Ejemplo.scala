package curso
/* OPTION type  una Option Scala almacena uno o cero elementos de un tipo
   Puede valer Some[T] o None

 */
object Ejemplo {
   val lista=List(1,2,3,4)
   val option1:Option[Int]=None
   val option2:Option[Int]=Some(10)

  def main(args: Array[String]): Unit = {
      println(lista.find(_>8))
      println(lista.find(_>1))
      println(lista.find(_>1).get)
      println(lista.find(_>8).getOrElse(0))
      //println(lista.find(_>8).get)
      println(option1.getOrElse(0))
    println(option2.getOrElse(0))
  }

}
