package curso
class Estudiante{

  def hola()
  {
    println("Primer metodo")
  }

  def hola(nombre:String){
    println("Segundo metodo "+nombre)
  }

   def hola(nombre:String,edad:Int){
     println("Tercer metodo "+nombre+edad.toString)
   }
}
object Principal {
  def main(args: Array[String]): Unit = {
      var estudiante1=new Estudiante()
      estudiante1.hola()
      estudiante1.hola("Alberto")
      estudiante1.hola("alberto",20)
  }
}
