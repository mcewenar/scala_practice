package curso

trait Trait1
{

  def Imprimir(nombre:String) : Unit


}

class Persona extends Trait1
{
  def  Imprimir (nombre:String):Unit={
        println(nombre.toUpperCase)
  }

}

object  Principal {
  def main(args: Array[String]): Unit = {
    var persona1=new Persona()
    persona1.Imprimir("alberto")

  }
}