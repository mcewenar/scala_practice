package curso

object Principal {

  def main(args: Array[String]): Unit = {

    //lectura de Fichero
    import scala.io.Source

    //opcion1
    val fichero="/tmp/f1.txt"
    for (linea<- Source.fromFile(fichero).getLines()){
      println(linea)
    }

    //opcion2
    val lineas=Source.fromFile("/tmp/f1.txt").getLines().toList
    lineas.foreach(x=>println(x))

    //opcion3
    val fichero1=Source.fromFile("/tmp/f1.txt")
    for (linea<- fichero1.getLines()){
      println(linea)
    }
    fichero1.close()

  }
}