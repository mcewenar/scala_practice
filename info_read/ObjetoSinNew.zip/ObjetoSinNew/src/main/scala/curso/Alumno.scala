package curso

// Clase principal
class Alumno{
   var nombre:String=_
}

//Companion Object
object Alumno{
  //Metodo apply
  def apply(nombre: String): Alumno
  = {
    var alumno1 = new Alumno
    alumno1.nombre=nombre
    alumno1
  }
}

//Metodo con main
object Principal{
  def main(args: Array[String]): Unit = {
      //Definir Objeto Alumno sin NEW
      var alumno=Alumno("Raul")
      println(alumno.nombre)
  }
}

