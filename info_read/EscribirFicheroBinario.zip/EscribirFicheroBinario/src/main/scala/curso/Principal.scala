package curso

object Principal {

  import java.io._

  def main(args: Array[String]): Unit = {
    var entrada = None: Option[FileInputStream]
    var salida = None: Option[FileOutputStream]
    try {
      entrada = Some(new FileInputStream("/tmp/ejemplo1.dat"))
      salida = Some(new FileOutputStream("/tmp/ejemplo.backup"))
      var caracter = 0
      while ( {
        caracter = entrada.get.read;caracter != -1 }) {
        salida.get.write(caracter)
      }
    } catch {
      case ex1: IOException => ex1.printStackTrace()
    } finally {
      println("Estamos dentro de finally")
      if (entrada.isDefined) entrada.get.close()
      if (salida.isDefined) salida.get.close()
    }
  }
}
