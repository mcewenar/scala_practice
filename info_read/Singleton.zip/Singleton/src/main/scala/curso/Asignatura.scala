package curso

object Asignatura {
    def aprobado {println("Aprobado")}
    def suspendido {println("Suspendido")}
}


object Principal{
  def main(args: Array[String]): Unit = {
  Asignatura.aprobado
  Asignatura.suspendido
  }
}