package curso

class Producto (var cod_producto:Int,var nombre:String){
  println("Estoy en el constructor")

  def imprimir: Unit ={
    println(s"El codigo es $cod_producto y se llama $nombre")
  }
  println("Sigo en el constructor")
}


object Principal {
  def main(args: Array[String]): Unit = {
    var producto1=new Producto(10,"tornillos")
    producto1.imprimir
    producto1.nombre="Tuercas"
    producto1.imprimir
  }


}